addpath('P:\2422045.01\faye\DCM\spm12\spm12\');
home_dir = 'P:\2422045.01\faye\DCM';
cd(home_dir);
% spm fmri;

subjects = {'102', '103', '104'};
% sessions = {'1','2'};
sessions = {'1'};

% load first level batch MAT TEMPLATE file
firstLevelSession = load("firstLevelSession_Template.mat");
S1 = firstLevelSession.matlabbatch{1, 1}.spm.stats.fmri_spec.sess(1);
% Note: to index structures, aim at indexing one level/field ABOVE the field you want to reach!
% S = 
% 
%   1×3 struct array with fields:
% 
%     scans
%     cond
%     multi
%     regress
%     multi_reg
%     hpf

% Copy subject 1's structure, then only change what is necessary (onsets
% and file names)

for session_idx = 1:length(sessions)
    session = sessions(session_idx);
    
    for subject_idx = 1:length(subjects)        % subject loop
        this_subject = subjects{subject_idx};   % get current subject
        
        % path to events file for current subject and session
        this_events = home_dir+"\session"+session+"\sub-"+this_subject+"\task-rsa_sub-"+this_subject+"_ses-0"+session+"_events.tsv";
        this_nifti = home_dir+"\session"+session+"\sub-"+this_subject+"\task-rsa_sub-"+this_subject+"_ses-0"+session+"_bold_mni.tsv";
        % print out the file name
        disp(this_events);
        
        % calls the import data function and saves as a table called "events"
        events = import_events(this_events);
        
        % drops all rows in the events table that are oddball
        g = events.oddball == 0;
        events = events(g,:);
        
        % onsets ALL GRAPHEMES (all letters except oddballs)
        onsetGraphemes = events(:,16);
        
        % get only COLORED GRAPHEMES
        cg = events.trial_type_color == 'color';
        colored_graphemes = events(cg,:);
        onsetColorGraphemes = colored_graphemes(:,16);
        
        % get only TRAINED GRAPHEMES
        tg = events.trial_type_letter == 'trained';
        trained_graphemes = events(tg,:);
        onsetTrainedGraphemes = trained_graphemes(:,16);
        
        % get 1xNsubjects structure from firstLevelSession variable
        % copy the first subject's structure, then change only file names and onsets
        SS = S1;
        
        % graphemes
        SS.cond(1).onset = table2array(onsetGraphemes);
        % colored graphemes
        SS.cond(2).onset = table2array(onsetColorGraphemes);
        % trained graphemes
        SS.cond(3).onset = table2array(onsetTrainedGraphemes);
        
        % scans: {1986×1 cell}
        % loop through each volume file name, change subject number and session
        for nii = 1:length(SS.scans)
            this_nii = SS.scans(nii);
            old = "sub-102";            % always first subject
            new = "sub-"+this_subject;  % current subject
            
            temp_string = strrep(this_nii{1},old,new);
            old = "session1";
            new = "session"+session;
            temp_string = strrep(temp_string,old,new);
            
            old = "ses-01";
            new = "ses-0"+session;
            
            SS.scans(nii) = cellstr(strrep(temp_string,old,new));
           
        end % end scan loop
        
        % save entire structure for current subject
        firstLevelSession.matlabbatch{1, 1}.spm.stats.fmri_spec.sess(subject_idx) = SS;
    end % end subject loop
    
    % make sure to save the newly created firstLevelSession MAT file!!
    M_filename = "firstLevelSession"+session+".mat";
    matlabbatch = firstLevelSession.matlabbatch;
    save(M_filename, "matlabbatch");
    
end % end session loop


